<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saudacao</title>
</head>
<body>
    <h1>Ola <?= $nome ?></h1> 
</body>
</html><?php /**PATH C:\treinaweb\tw-projeto\resources\views/saudacao.blade.php ENDPATH**/ ?>