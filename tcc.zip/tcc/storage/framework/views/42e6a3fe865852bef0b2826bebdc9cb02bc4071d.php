<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do serviço</title>
</head>
<body>
    <h1><?php echo e($servico['nome']); ?></h1>
    <p><?php echo e($servico['descricao']); ?></p>
    <p><?php echo e($outro); ?></p>
</body>
</html><?php /**PATH C:\treinaweb\tw-projeto\resources\views/site/servico.blade.php ENDPATH**/ ?>