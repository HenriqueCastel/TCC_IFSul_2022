

<?php $__env->startSection('titulo', 'Página inicial'); ?>

<?php $__env->startSection('conteudo'); ?>
    <h1>Home</h1>
    <p>Bem vindo ao sistema! Acesse o cadastro de clientes no menu.</p>
<?php $__env->stopSection(); ?>




    
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\treinaweb\tw-projeto\resources\views/home.blade.php ENDPATH**/ ?>